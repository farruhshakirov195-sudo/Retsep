# RETSEP — boshlang‘ich Flutter loyiha

Bu Android va iOS uchun Flutter asosidagi boshlang‘ich loyiha. Hozirgi kod:
- qizil-yashil rangli interfeys;
- namunaviy dori katalogi va qidiruv;
- savat va jami summani hisoblash;
- savdoni telefondagi SQLite bazasiga saqlash;
- savdolar tarixini ko‘rsatish.

## Ishga tushirish
1. Flutter SDK o‘rnating.
2. Terminalda loyiha papkasiga kiring.
3. `flutter pub get`
4. `flutter run`

## Muhim cheklovlar
Bu MVP boshlang‘ich kodi. Hozircha haqiqiy akkaunt/ro‘yxatdan o‘tish, server, turli telefonlar o‘rtasida sinxronlash, to‘lov, chek printeri va real dorixona katalogi ulanmagan. Sinov dorilari va narxlari namuna — haqiqiy narxlar emas.

Bir nechta telefon o‘rtasida xavfsiz ishlashi uchun keyingi bosqichda server API, foydalanuvchi rollari, autentifikatsiya, sinxronlash navbati va ziddiyatlarni hal qilish mexanizmi kerak. Parollarni oddiy matnda saqlamang; ishlab chiqarish tizimida server tomonda xavfsiz autentifikatsiya ishlating.

Dori narxlari va qoldiqlarini ishga tushirishdan oldin dorixona egasi tasdiqlashi kerak. Dorilarni qo‘llash bo‘yicha tibbiy tavsiya bermaydi.
