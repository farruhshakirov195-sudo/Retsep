import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class RetsepDb {
  RetsepDb._();
  static final instance = RetsepDb._();
  Database? _db;

  Future<void> init() async {
    final dir = await getDatabasesPath();
    _db = await openDatabase(join(dir, 'retsep.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            price INTEGER NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            total INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            items_json TEXT NOT NULL
          )
        ''');
      });
    await seedIfEmpty();
  }

  Database get db => _db!;

  Future<void> seedIfEmpty() async {
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products')) ?? 0;
    if (count > 0) return;
    final batch = db.batch();
    final samples = [
      ['Paratsetamol', '500 mg · 10 tabletka', 5000, 30],
      ['Ibuprofen', '400 mg · 10 tabletka', 12000, 20],
      ['Amoksitsillin', '500 mg · 16 kapsula', 25000, 15],
      ['Loratadin', '10 mg · 10 tabletka', 9000, 25],
      ['Vitamin C', '500 mg · 20 tabletka', 18000, 12],
    ];
    for (final p in samples) {
      batch.insert('products', {'name': p[0], 'description': p[1], 'price': p[2], 'stock': p[3]});
    }
    await batch.commit(noResult: true);
  }

  Future<List<Map<String, Object?>>> products(String query) => db.query(
    'products', where: 'name LIKE ?', whereArgs: ['%$query%'], orderBy: 'name');

  Future<void> saveSale(List<Map<String, Object?>> items, int total) async {
    final now = DateTime.now().toIso8601String();
    final encoded = items.map((p) => '${p['name']}|${p['price']}').join(';');
    await db.insert('sales', {'total': total, 'created_at': now, 'items_json': encoded});
  }

  Future<List<Map<String, Object?>>> sales() => db.query('sales', orderBy: 'id DESC');
}
