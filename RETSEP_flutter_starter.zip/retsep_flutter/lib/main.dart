import 'package:flutter/material.dart';
import 'db.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await RetsepDb.instance.init();
  runApp(const RetsepApp());
}

const red = Color(0xFFB3262D);
const green = Color(0xFF176B43);

class RetsepApp extends StatelessWidget {
  const RetsepApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'RETSEP',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: green, primary: green),
      scaffoldBackgroundColor: const Color(0xFFF7F8F7),
      appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';
  List<Map<String, Object?>> products = [];
  List<Map<String, Object?>> cart = [];

  @override
  void initState() { super.initState(); refresh(); }

  Future<void> refresh() async {
    final rows = await RetsepDb.instance.products(query);
    if (mounted) setState(() => products = rows);
  }

  int get total => cart.fold(0, (sum, p) => sum + (p['price'] as int));

  Future<void> finishSale() async {
    if (cart.isEmpty) return;
    await RetsepDb.instance.saveSale(cart, total);
    if (!mounted) return;
    setState(() => cart = []);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Savdo telefonda saqlandi.')),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Row(children: [
        Icon(Icons.local_pharmacy), SizedBox(width: 9),
        Text('RETSEP', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
      ]),
      actions: [IconButton(onPressed: () async {
        await RetsepDb.instance.seedIfEmpty();
        await refresh();
      }, icon: const Icon(Icons.refresh), tooltip: 'Namuna dorilar')],
    ),
    body: tab == 0 ? catalog() : tab == 1 ? basket() : sales(),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.medication_outlined), label: 'Dorilar'),
        NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'Savat'),
        NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Savdolar'),
      ],
    ),
  );

  Widget catalog() => Column(children: [
    Padding(
      padding: const EdgeInsets.all(12),
      child: TextField(
        decoration: const InputDecoration(
          hintText: 'Dori nomini qidiring',
          prefixIcon: Icon(Icons.search),
          border: OutlineInputBorder(),
          filled: true,
        ),
        onChanged: (v) { query = v; refresh(); },
      ),
    ),
    Expanded(child: products.isEmpty
      ? const Center(child: Text('Dori topilmadi. Namuna dorilarni yuklash uchun yuqoridagi tugmani bosing.'))
      : ListView.separated(
        itemCount: products.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final p = products[i];
          return ListTile(
            title: Text('${p['name']}'),
            subtitle: Text('${p['description']}'),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${(p['price'] as int).toString()} so‘m', style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Savatga qo‘shish', style: TextStyle(fontSize: 11, color: red)),
            ]),
            onTap: () => setState(() => cart.add(p)),
          );
        },
      )),
  ]);

  Widget basket() => Column(children: [
    Expanded(child: cart.isEmpty
      ? const Center(child: Text('Savat bo‘sh'))
      : ListView.builder(
        itemCount: cart.length,
        itemBuilder: (_, i) {
          final p = cart[i];
          return ListTile(
            title: Text('${p['name']}'),
            subtitle: Text('${p['price']} so‘m'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline, color: red),
              onPressed: () => setState(() => cart.removeAt(i))),
          );
        },
      )),
    Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Jami:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('$total so‘m', style: const TextStyle(fontSize: 20, color: green, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green),
          onPressed: cart.isEmpty ? null : finishSale,
          child: const Text('Sotuvni saqlash'),
        )),
      ]),
    ),
  ]);

  Widget sales() => FutureBuilder<List<Map<String, Object?>>>(
    future: RetsepDb.instance.sales(),
    builder: (_, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final rows = snap.data!;
      if (rows.isEmpty) return const Center(child: Text('Hozircha savdo yo‘q'));
      return ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) => ListTile(
          leading: const Icon(Icons.receipt, color: green),
          title: Text('Savdo #${rows[i]['id']}'),
          subtitle: Text('${rows[i]['created_at']}'),
          trailing: Text('${rows[i]['total']} so‘m', style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      );
    },
  );
}
